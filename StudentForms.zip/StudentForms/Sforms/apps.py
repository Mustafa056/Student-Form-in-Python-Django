from django.apps import AppConfig


class SformsConfig(AppConfig):
    name = 'Sforms'
