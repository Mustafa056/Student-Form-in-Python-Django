from django.shortcuts import render,redirect,HttpResponse
from django.conf import settings
from .models import Contact

def index(request):

    if request.method=="POST":
        usn=request.POST.get('usn','')
        name=request.POST.get('name','')
        sem=request.POST.get('sem','')
        phn=request.POST.get('phn','')
        email=request.POST.get('email','')

        if usn and name and sem and email:
            contact=Contact(usn=usn,name=name,sem=sem,phn=phn,email=email)
            contact.save() 

        else:
            
            return HttpResponse("Enter ALL Details")  

    return render(request,'index.html')

